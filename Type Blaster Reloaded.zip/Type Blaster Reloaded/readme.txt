App: Type Blaster Reloaded
version: 1.0

Creator: Matt Hamersky
Email: hamerskymatthew@yahoo.com

Any questions, comments, suggestions, or bugs please contact me.


FAQ:

Q: This game is too easy.
A:  First, that's not a question.  Second, the levels are designed so that the
first few levels can be completed by anyone with even rudimentary typing skills.  The
difficulty increases as the levels progress.  If you want a challenge, play the
legendary difficulty levels.  If even levels 5-10 on legendary are too easy for you
then you are too good and need to find a different game.

Q: Is there any sound?
A: Nope

Q: Why is there no sound?
A: Sound effects take a fair amount of time to create and if you are like me and can't
mix sounds to save your life then it is easier to leave them out of the game.  I could 
have lifted sounds from somewhere else (there are a ton of free sound sites out there) but 
sounds are unique in that it is really easy to notice when different sounds were created
by different people with different purposes in mind.  Trying to find sounds that work well
together when you get one from one site and two more from somewhere else and three from 
somewhere else takes a considerable amount of time-much more than I wanted to spend.
You can play the game like I do, listening to your own music in the background :)

Q: Is the source code available?
A: It can be found here: (insert github link whenever I get around to pushing it)

Q: What language and/or library did you use to make the game?
A: I used Java for the language and Slick2D as my engine.
https://www.java.com/en/
http://slick.ninjacave.com/

Thanks for playing!
